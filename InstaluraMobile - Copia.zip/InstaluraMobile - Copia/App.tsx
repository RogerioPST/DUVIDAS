import React from 'react';
//o react native ja tem uma API para pegar as dimensoes dos nossos dispositivos
import { 
  StyleSheet, 
  Text, 
  View, 
  Image,
  Dimensions,
  ScrollView, 
  FlatList
} from 'react-native';

import Post from './src/components/Post';


//o react native ja tem uma API para pegar as dimensoes dos nossos dispositivos
const width = Dimensions.get('screen').width;
const height = Dimensions.get('screen').height;

export default function App() {  
  const fotos =[     {id:1, usuario: 'rafael'},     {id:2, usuario: 'rogerio'},    {id:3, usuario: 'vanessa'},  ];
  return (  
    <FlatList style={styles.container}
    keyExtractor={item => item.id.toString()}
    data={fotos}
    renderItem={ ({item}) =>
    <Post foto={item} />
    }
    />        
  );

  

}

const styles = StyleSheet.create({
  container: {marginTop: 20},
  cabecalho : {margin: 10, flexDirection: 'row', alignItems: 'center'},
  fotoDePerfil: {marginRight: 10, borderRadius: 20,  width: 40, height: 40},
  foto: {width: width, height: width},

})




