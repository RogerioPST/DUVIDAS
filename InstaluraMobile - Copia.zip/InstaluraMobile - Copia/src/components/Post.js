import React, { Component } from 'react';
//o react native ja tem uma API para pegar as dimensoes dos nossos dispositivos
import { 
  StyleSheet, 
  Text, 
  View, 
  Image,
  Dimensions,
  ScrollView, 
  FlatList
} from 'react-native';


//o react native ja tem uma API para pegar as dimensoes dos nossos dispositivos
const width = Dimensions.get('screen').width;
const height = Dimensions.get('screen').height;

export default class Post extends Component {  
  render(){
       
  return (   
    <View>
      <View style={styles.cabecalho}>
      <Image source={require('../../resources/img/felix.jpg')} 
        style={styles.fotoDePerfil} />
      <Text>{this.props.foto.usuario}</Text>
      </View>
      <Image source={require('../../resources/img/felix.jpg')} 
        style={styles.foto} />
    </View>                
  );
}
}


const styles = StyleSheet.create({
  container: {marginTop: 20},
  cabecalho : {margin: 10, flexDirection: 'row', alignItems: 'center'},
  fotoDePerfil: {marginRight: 10, borderRadius: 20,  width: 40, height: 40},
  foto: {width: width, height: width},

})




